# ADL checker for AirDC++ Web Client

Checks your share against an `ADLSearch.xml` file (the same rules and the same matching logic as `adlchecker.py`).

* **Warnings in the event log** when a file or directory that matches a rule is added to the share (shown with severity *warning*). New directories are checked when they are added, files after their directory has been hashed.
* **Do not share matched files** (option, off by default): a matched file is left out of the share when it is added. Only items that are new to the share can be left out: files and directories that are already shared are not removed. In this mode AirDC++ asks the extension about every new file and waits for the answer.
* **See all matches**: `/adl matches` (or the extension menu item *Show ADL matches*) opens the complete list, grouped by category, in the application's text viewer. The list also shows the files and folders that the last scan could not read, with the reason.
* **Updates from a web address** (optional): the extension can compare your `ADLSearch.xml` with a file at a web address (for example in a GitHub repository), tell you in the event log if they differ, and install the new one on request (`/adl update` or *ADL Update* in the extension menu). It never replaces the file by itself, and the old file is kept as `ADLSearch.xml.bak`.
* **Reload** the ADL file after you have replaced it: `/adl reload` or *ADL Reload* in the extension menu.
* **Scan the whole share** on demand: `/adl scan` or the menu item *Check the share against the ADL rules*.

## Install

AirDC++ doesn't install dependencies for extensions; everything is bundled in `dist/main.js`.

1. Copy the folder `airdcpp-adl-checker` (it contains `package.json` and `dist/main.js`) to the `extensions` directory in the application settings directory, e.g. `…/Settings/extensions/airdcpp-adl-checker`.
2. Restart the application (the directory is scanned only at startup).
3. Make sure `ADLSearch.xml` is in the application settings directory (the folder that contains `extensions`). Check the event log for `ADL checker: loaded N rules`.

Requires a Node.js version supported by the application (developed and tested on Node 22) and application API feature level 4 or newer. Opening the match list in the viewer needs feature level 6 or newer; with an older version the list is saved to `adl-matches.txt` in the extension's log directory instead.

## Settings

| Setting | Default | |
|---|---|---|
| Check files and directories when they are added to share | on | Warnings for new directories and for the files of hashed directories (each item is warned about only once). Turning it off removes the extension from share refreshes completely. |
| Do not share matched files and directories | off | |
| Ignore the items listed in ADLSearch.ignorelist | on | Exact full paths, one per line, in `ADLSearch.ignorelist` next to `ADLSearch.xml`. |
| URL to ADLSearch.xml | empty (off) | Link to an `ADLSearch.xml` (`http://` or `https://`; a GitHub page address such as `https://github.com/<owner>/<repo>/blob/main/ADLSearch.xml` also works). Checked when the extension starts (a few seconds after startup) and with `/adl check`. If you edit the file yourself it will differ from the downloaded one and you are told at every startup; clear the setting to turn this off. A server may serve a cached copy for a few minutes after the file changes. |
| Maximum number of individual warnings in a row | 100 | The rest is summarized in a single warning. |

`ADLSearch.xml` and `ADLSearch.ignorelist` are read when the extension starts and when you reload them (`/adl reload` or the extension menu item *ADL Reload*). There is no automatic check for changes.

## Commands (hub/private chat; need admin or settings_edit permission)

`/adl scan`, `/adl matches`, `/adl list` (counts per category), `/adl reload`, `/adl check` (is there a different ADLSearch.xml at the address?), `/adl update` (download it, keep the old one as `ADLSearch.xml.bak`, reload), `/help`

The extension menu has the same actions: *Check the share…*, *ADL Reload*, *ADL Check for update*, *ADL Update*, *Show ADL matches*.

## What is checked: the share, not the disk

Only items that are in the share are reported. Files on disk that are excluded from the share or otherwise not shared are ignored.

* **`/adl scan`** reads the share cache files of AirDC++ (`<settings folder>/ShareCache/*.xml`, one per share root; the same files `adlchecker.py` reads) and checks every directory and file listed there. The disk is not walked, so folders you have no permission to read do not matter. The scan result tells when the cache files were saved: the cache is written when the share changes and can be a little behind, so very recent changes may be missing. Size limits in the ADL rules use the file size on disk (the cache has no sizes), and, as in `adlchecker.py`, a file that is listed in the cache but can't be found on the disk is not reported (the scan result tells how many were skipped for that reason). Unlike the script, which uses one share profile, the scan covers all share roots of all profiles.
* A share root without a readable cache file, or with a cache `Version` other than 3 (the only version this was written and tested for), is scanned from the disk instead. For those roots every match is confirmed with AirDC++ (`share/check_path_shared`, needs API feature level 6), and folders/files that can't be read are listed in `/adl matches`. The scan result says how many roots were read from the disk.
* **Newly hashed directories** are checked from the disk right after hashing, and each match is confirmed with `share/check_path_shared`. Items that are not in the share yet are checked again after 3, 15 and 60 seconds. With an older application version the share can't be asked, and a warning in the event log tells that files on disk can then be reported too.

Run `/adl scan` once after updating from an older version of the extension: it replaces the stored list of matches, which could contain files that are not in the share.

## Matching rules

Only active regular expression entries are used (`RegEx="1"`, `IsActive=1`), the same as in `adlchecker.py`: source types Filename / Directory / Full Path, size limits (B/KiB/MiB/GiB, -1 = no limit, ignored for directories). Boost regexes are converted to JavaScript ones; an entry whose pattern can't be converted exactly is skipped and reported in the event log instead of being guessed.

## Known limitations

* Verified against `adlchecker.py` with your `ADLSearch.xml` on ~364,000 generated names: identical results, with one known difference: the letters `İ`/`ı` (Python case-folds `İ` to `i`, JavaScript doesn't).
* In reject mode the application waits for the extension's answer for every file during share refreshes. The extension therefore doesn't touch the file system for this (the file size comes from the data the application sends), and it always answers within 3 seconds: if a check takes longer, the item is accepted and an error is written to the extension log. Every 10 seconds while file checks are happening, a line with the number of checks is written to the extension log.
* Left-out files stay on disk, they are simply not shared. After you disable the option, they are shared again on the next refresh.
