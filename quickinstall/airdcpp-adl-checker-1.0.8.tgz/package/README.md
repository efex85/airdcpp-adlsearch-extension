# ADL checker for AirDC++ Web Client

Checks your share against an `ADLSearch.xml` file (the same rules and the same matching logic as `adlchecker.py`).

* **Warnings in the event log** when a file or directory that matches a rule is added to the share (shown with severity *warning*). New directories are checked when they are added, files after their directory has been hashed.
* **Do not share matched files** (option, off by default): the matched file is left out of the share when the share is refreshed. Directories can be left out only when they are new in the share. Note: this is the only mode where AirDC++ asks the extension about every single file during share refreshes, and it waits for each answer. That can make refreshes of big shares much slower, so leave it off if warnings are enough.
* **See all matches**: `/adl matches` (or the extension menu item *Show ADL matches*) opens the complete list, grouped by category, in the application's text viewer. The list also shows the files and folders that the last scan could not read, with the reason.
* **Updates from GitHub** (optional): the extension can compare your `ADLSearch.xml` with a file in a public GitHub repository, tell you in the event log if they differ, and install the new one on request (`/adl update` or *ADL Update* in the extension menu). It never replaces the file by itself, and the old file is kept as `ADLSearch.xml.bak`.
* **Reload** the ADL file after you have replaced it: `/adl reload` or *ADL Reload* in the extension menu.
* **Scan the whole share** on demand: `/adl scan` or the menu item *Check the share against the ADL rules*.

## Install

AirDC++ doesn't install dependencies for extensions; everything is bundled in `dist/main.js`.

1. Copy the folder `airdcpp-adl-checker` (it contains `package.json` and `dist/main.js`) to the `extensions` directory in the application settings directory, e.g. `…/Settings/extensions/airdcpp-adl-checker`.
2. Restart the application (the directory is scanned only at startup).
3. Make sure `ADLSearch.xml` is in the application settings directory (the folder that contains `extensions`). Check the event log for `ADL checker: loaded N rules`.

Requires a Node.js version supported by the application (developed and tested on Node 22) and application API feature level 4 or newer. Opening the match list in the viewer needs feature level 6 or newer; with an older version the list is saved to `adl-matches.txt` in the extension's log directory instead.

## Settings

| Setting | Default | |
|---|---|---|
| Check files and directories when they are added to share | on | Warnings for new directories and for the files of hashed directories (each item is warned about only once). Turning it off removes the extension from share refreshes completely. |
| Do not share matched files and directories | off | |
| Ignore the items listed in ADLSearch.ignorelist | on | Exact full paths, one per line, in `ADLSearch.ignorelist` next to `ADLSearch.xml`. |
| Address of ADLSearch.xml in a GitHub repository (for updates) | empty (off) | For example `https://github.com/<owner>/<repo>/blob/main/ADLSearch.xml`. Checked when the extension starts (a few seconds after startup) and with `/adl check`. Only `github.com` and `raw.githubusercontent.com` addresses are accepted. If you edit the file yourself it will differ from the repository, and you are told about that at every startup; clear the setting to turn this off. GitHub may serve a cached copy of a file for a few minutes after it changes. |
| Maximum number of individual warnings in a row | 100 | The rest is summarized in a single warning. |

`ADLSearch.xml` and `ADLSearch.ignorelist` are read when the extension starts and when you reload them (`/adl reload` or the extension menu item *ADL Reload*). There is no automatic check for changes.

## Commands (hub/private chat; need admin or settings_edit permission)

`/adl scan`, `/adl matches`, `/adl list` (counts per category), `/adl reload`, `/adl check` (is there a different ADLSearch.xml in the GitHub repository?), `/adl update` (download it, keep the old one as `ADLSearch.xml.bak`, reload), `/help`

The extension menu has the same actions: *Check the share…*, *ADL Reload*, *ADL Check for update*, *ADL Update*, *Show ADL matches*.

## Matching rules

Only active regular expression entries are used (`RegEx="1"`, `IsActive=1`), the same as in `adlchecker.py`: source types Filename / Directory / Full Path, size limits (B/KiB/MiB/GiB, -1 = no limit, ignored for directories). Boost regexes are converted to JavaScript ones; an entry whose pattern can't be converted exactly is skipped and reported in the event log instead of being guessed.

## Known limitations

* Verified against `adlchecker.py` with your `ADLSearch.xml` on ~364,000 generated names: identical results, with one known difference: the letters `İ`/`ı` (Python case-folds `İ` to `i`, JavaScript doesn't).
* In reject mode the application waits for the extension's answer for every file during share refreshes. The extension therefore doesn't touch the file system for this (the file size comes from the data the application sends), and it always answers within 3 seconds: if a check takes longer, the item is accepted and an error is written to the extension log. Every 10 seconds while file checks are happening, a line with the number of checks is written to the extension log.
* Left-out files stay on disk, they are simply not shared. After you disable the option, they are shared again on the next refresh.
